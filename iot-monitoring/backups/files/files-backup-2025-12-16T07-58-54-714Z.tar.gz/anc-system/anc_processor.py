#!/usr/bin/env python3
# =====================================================
# 🎧 ANC (Active Noise Cancelling) 실시간 처리기
# =====================================================
# 노트북에서 실행! (Pico와 USB 연결된 상태에서)
#
# 역할:
#   1. Pico에서 마이크 데이터 수신 (USB Serial)
#   2. ANC 역산 계산 (실시간)
#   3. 상쇄음 데이터를 Pico로 전송 (진동자 출력용)
#   4. dB 수치를 Pi 5 서버로 전송 (UI 표시용, 딜레이 OK)

import serial
import serial.tools.list_ports
import numpy as np
import threading
import queue
import time
import requests
from collections import deque

# =====================================================
# 📌 설정
# =====================================================
# Pico USB Serial
BAUD_RATE = 921600          # 고속 통신 (실시간용)
SAMPLE_RATE = 44100         # 오디오 샘플레이트
BUFFER_SIZE = 256           # 버퍼 크기 (작을수록 지연 적음)

# Pi 5 서버 (UI용 데이터 전송)
PI5_SERVER = "http://192.168.35.33:3001"  # Pi 5 IP 주소
DEVICE_ID = "raspberry-pi-01"
SEND_INTERVAL = 1.0         # Pi 5로 전송 간격 (초) - 딜레이 OK

# ANC 설정
ANC_ENABLED = True
FILTER_LENGTH = 128         # 적응 필터 길이

# =====================================================
# ANC 클래스 (LMS 적응 필터)
# =====================================================
class AdaptiveANC:
    """LMS (Least Mean Squares) 기반 적응형 노이즈 캔슬링"""
    
    def __init__(self, filter_length=128, step_size=0.01):
        self.filter_length = filter_length
        self.step_size = step_size
        self.weights = np.zeros(filter_length)
        self.buffer = deque(maxlen=filter_length)
        
        # 초기 버퍼 채우기
        for _ in range(filter_length):
            self.buffer.append(0.0)
    
    def process(self, input_sample, reference_sample):
        """
        입력 샘플과 참조 신호를 받아 상쇄음 생성
        
        Args:
            input_sample: 마이크 입력 (노이즈)
            reference_sample: 참조 신호 (원본 노이즈 추정)
        
        Returns:
            anti_noise: 상쇄음 (진동자로 출력할 신호)
            error: 잔여 노이즈 (상쇄 후 남은 소리)
        """
        # 버퍼 업데이트
        self.buffer.append(reference_sample)
        x = np.array(self.buffer)
        
        # 상쇄음 생성 (FIR 필터 적용)
        anti_noise = -np.dot(self.weights, x)
        
        # 오차 계산 (마이크 입력 + 상쇄음)
        error = input_sample + anti_noise
        
        # LMS 가중치 업데이트
        self.weights += 2 * self.step_size * error * x
        
        return anti_noise, error
    
    def process_block(self, input_block):
        """
        블록 단위 처리 (더 효율적)
        """
        output_block = np.zeros_like(input_block)
        error_block = np.zeros_like(input_block)
        
        for i, sample in enumerate(input_block):
            anti_noise, error = self.process(sample, sample)
            output_block[i] = anti_noise
            error_block[i] = error
        
        return output_block, error_block


# =====================================================
# dB 계산 함수
# =====================================================
def calculate_db(samples):
    """RMS를 dB로 변환"""
    if len(samples) == 0:
        return 0.0
    
    # RMS 계산
    rms = np.sqrt(np.mean(np.square(samples.astype(float))))
    
    if rms > 0:
        # dB 변환 (기준: 16-bit max = 0 dBFS)
        db = 20 * np.log10(rms / 32768)
        # SPL로 대략 변환 (마이크 감도에 따라 조정 필요)
        db_spl = db + 94  # 0 dBFS ≈ 94 dB SPL
        return max(0, min(120, db_spl))
    return 0.0


# =====================================================
# Pico 시리얼 통신 클래스
# =====================================================
class PicoSerial:
    def __init__(self):
        self.serial = None
        self.connected = False
    
    def find_pico(self):
        """Pico 포트 자동 탐지"""
        ports = serial.tools.list_ports.comports()
        for port in ports:
            desc = port.description.lower()
            if any(k in desc for k in ['pico', 'rp2', 'board', 'usb serial']):
                return port.device
        # 못 찾으면 첫 번째 시리얼 포트 시도
        for port in ports:
            if 'COM' in port.device or 'tty' in port.device:
                return port.device
        return None
    
    def connect(self):
        """Pico 연결"""
        port = self.find_pico()
        if not port:
            print("❌ Pico를 찾을 수 없습니다!")
            print("   사용 가능한 포트:")
            for p in serial.tools.list_ports.comports():
                print(f"   - {p.device}: {p.description}")
            return False
        
        try:
            self.serial = serial.Serial(
                port, 
                BAUD_RATE, 
                timeout=0.001,  # 매우 짧은 타임아웃 (실시간)
                write_timeout=0.001
            )
            self.connected = True
            print(f"✓ Pico 연결됨: {port}")
            return True
        except Exception as e:
            print(f"❌ 연결 실패: {e}")
            return False
    
    def read_samples(self, count):
        """Pico에서 오디오 샘플 읽기"""
        if not self.connected:
            return None
        
        try:
            # 바이너리로 읽기 (16-bit signed)
            data = self.serial.read(count * 2)
            if len(data) >= 2:
                samples = np.frombuffer(data, dtype=np.int16)
                return samples
        except:
            pass
        return None
    
    def write_samples(self, samples):
        """Pico로 상쇄음 샘플 전송"""
        if not self.connected:
            return False
        
        try:
            data = samples.astype(np.int16).tobytes()
            self.serial.write(data)
            return True
        except:
            return False
    
    def close(self):
        if self.serial:
            self.serial.close()


# =====================================================
# Pi 5 서버 전송 (별도 스레드)
# =====================================================
class Pi5Sender:
    def __init__(self, server_url, device_id):
        self.server_url = server_url
        self.device_id = device_id
        self.data_queue = queue.Queue()
        self.running = False
        self.thread = None
    
    def start(self):
        """전송 스레드 시작"""
        self.running = True
        self.thread = threading.Thread(target=self._send_loop, daemon=True)
        self.thread.start()
        print(f"✓ Pi 5 전송 스레드 시작 ({self.server_url})")
    
    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join(timeout=2)
    
    def queue_data(self, original_db, cancelled_db):
        """데이터를 큐에 추가 (논블로킹)"""
        try:
            self.data_queue.put_nowait({
                "original_db": round(original_db, 2),
                "cancelled_db": round(cancelled_db, 2),
                "device_id": self.device_id
            })
        except queue.Full:
            pass  # 큐 가득 차면 드랍 (UI용이라 OK)
    
    def _send_loop(self):
        """백그라운드에서 Pi 5로 데이터 전송"""
        while self.running:
            try:
                # 큐에서 최신 데이터만 가져오기 (오래된 건 버림)
                data = None
                while not self.data_queue.empty():
                    data = self.data_queue.get_nowait()
                
                if data:
                    response = requests.post(
                        f"{self.server_url}/api/sensor/noise",
                        json=data,
                        timeout=2
                    )
                    if response.status_code == 200:
                        print(f"  📡 Pi5 전송: {data['original_db']}dB → {data['cancelled_db']}dB")
                
                time.sleep(SEND_INTERVAL)
                
            except requests.exceptions.ConnectionError:
                print("  ⚠️ Pi 5 서버 연결 안됨")
                time.sleep(5)
            except Exception as e:
                print(f"  ⚠️ 전송 오류: {e}")
                time.sleep(1)


# =====================================================
# 메인 ANC 프로세서
# =====================================================
class ANCProcessor:
    def __init__(self):
        self.pico = PicoSerial()
        self.anc = AdaptiveANC(FILTER_LENGTH)
        self.pi5_sender = Pi5Sender(PI5_SERVER, DEVICE_ID)
        self.running = False
        
        # 통계
        self.sample_count = 0
        self.last_stats_time = time.time()
        self.original_db_avg = 0
        self.cancelled_db_avg = 0
    
    def start(self):
        """ANC 처리 시작"""
        print("=" * 60)
        print("🎧 ANC (Active Noise Cancelling) 프로세서")
        print("=" * 60)
        
        # Pico 연결
        if not self.pico.connect():
            return False
        
        # Pi 5 전송 스레드 시작
        self.pi5_sender.start()
        
        print(f"\n⚙️ 설정:")
        print(f"   샘플레이트: {SAMPLE_RATE} Hz")
        print(f"   버퍼 크기: {BUFFER_SIZE}")
        print(f"   예상 지연: {BUFFER_SIZE / SAMPLE_RATE * 1000:.2f} ms")
        print(f"   Pi 5 전송 간격: {SEND_INTERVAL}초")
        print("-" * 60)
        print("🎤 실시간 ANC 처리 중... (Ctrl+C로 종료)\n")
        
        self.running = True
        self._process_loop()
        
        return True
    
    def _process_loop(self):
        """실시간 ANC 처리 루프"""
        original_samples = []
        cancelled_samples = []
        
        try:
            while self.running:
                # 1. Pico에서 마이크 데이터 읽기
                samples = self.pico.read_samples(BUFFER_SIZE)
                
                if samples is None or len(samples) == 0:
                    continue
                
                # 2. ANC 처리 (실시간!)
                if ANC_ENABLED:
                    anti_noise, error = self.anc.process_block(samples)
                else:
                    anti_noise = np.zeros_like(samples)
                    error = samples
                
                # 3. 상쇄음을 Pico로 전송 (진동자 출력)
                self.pico.write_samples(anti_noise.astype(np.int16))
                
                # 4. dB 계산용 샘플 수집
                original_samples.extend(samples)
                cancelled_samples.extend(error)
                
                self.sample_count += len(samples)
                
                # 5. 주기적으로 dB 계산 및 Pi 5 전송
                now = time.time()
                if now - self.last_stats_time >= SEND_INTERVAL:
                    if len(original_samples) > 0:
                        original_db = calculate_db(np.array(original_samples))
                        cancelled_db = calculate_db(np.array(cancelled_samples))
                        reduction = original_db - cancelled_db
                        
                        # 콘솔 출력
                        print(f"🔊 원본: {original_db:.1f}dB  "
                              f"🔇 상쇄후: {cancelled_db:.1f}dB  "
                              f"📉 감소: {reduction:.1f}dB  "
                              f"({self.sample_count} samples)")
                        
                        # Pi 5로 전송 (큐에 추가, 논블로킹)
                        self.pi5_sender.queue_data(original_db, cancelled_db)
                        
                        # 리셋
                        original_samples = []
                        cancelled_samples = []
                        self.sample_count = 0
                    
                    self.last_stats_time = now
                    
        except KeyboardInterrupt:
            print("\n\n👋 종료 중...")
        finally:
            self.stop()
    
    def stop(self):
        """정리"""
        self.running = False
        self.pi5_sender.stop()
        self.pico.close()
        print("✓ ANC 프로세서 종료됨")


# =====================================================
# 메인
# =====================================================
if __name__ == "__main__":
    processor = ANCProcessor()
    processor.start()
