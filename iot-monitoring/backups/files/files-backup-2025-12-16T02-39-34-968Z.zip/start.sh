#!/bin/bash
# =====================================================
# 🏠 Smart Home IoT 모니터링 시스템 실행 스크립트
# =====================================================

set -e

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 프로젝트 경로
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend/iot-dashboard"
RPI_DIR="$PROJECT_DIR/raspberry-pi"
DB_DIR="$PROJECT_DIR/database"

echo -e "${CYAN}"
echo "═══════════════════════════════════════════════════════════════"
echo "  🏠 Smart Home IoT Monitoring System"
echo "═══════════════════════════════════════════════════════════════"
echo -e "${NC}"

# 함수: 도움말 출력
show_help() {
    echo -e "${YELLOW}사용법:${NC}"
    echo "  ./start.sh [옵션]"
    echo ""
    echo -e "${YELLOW}옵션:${NC}"
    echo "  all         - 전체 시스템 시작 (DB, Backend, Frontend)"
    echo "  backend     - 백엔드 서버만 시작"
    echo "  frontend    - 프론트엔드만 시작"
    echo "  sensor      - 라즈베리파이 센서 수집 시작"
    echo "  pdlc        - PDLC 제스처 제어 시작"
    echo "  db-init     - 데이터베이스 초기화 (schema.sql 실행)"
    echo "  install     - 의존성 설치"
    echo "  stop        - 모든 프로세스 종료"
    echo "  status      - 시스템 상태 확인"
    echo "  help        - 도움말 표시"
    echo ""
    echo -e "${YELLOW}예시:${NC}"
    echo "  ./start.sh all       # 전체 시스템 시작"
    echo "  ./start.sh backend   # 백엔드만 시작"
    echo "  ./start.sh sensor    # 센서 수집 시작"
}

# 함수: 의존성 설치
install_dependencies() {
    echo -e "${BLUE}📦 의존성 설치 중...${NC}"
    
    # Backend 의존성
    if [ -d "$BACKEND_DIR" ]; then
        echo -e "${CYAN}  → Backend 의존성 설치...${NC}"
        cd "$BACKEND_DIR"
        npm install
    fi
    
    # Frontend 의존성
    if [ -d "$FRONTEND_DIR" ]; then
        echo -e "${CYAN}  → Frontend 의존성 설치...${NC}"
        cd "$FRONTEND_DIR"
        npm install
    fi
    
    # Raspberry Pi Python 의존성
    if [ -d "$RPI_DIR" ]; then
        echo -e "${CYAN}  → Raspberry Pi Python 의존성 설치...${NC}"
        cd "$RPI_DIR"
        if [ ! -d "venv" ]; then
            python3 -m venv venv
        fi
        source venv/bin/activate
        pip install -r requirements.txt
        pip install requests
        deactivate
    fi
    
    echo -e "${GREEN}✅ 의존성 설치 완료${NC}"
}

# 함수: 데이터베이스 초기화
init_database() {
    echo -e "${BLUE}🗄️ 데이터베이스 초기화 중...${NC}"
    
    if [ ! -f "$DB_DIR/schema.sql" ]; then
        echo -e "${RED}❌ schema.sql 파일을 찾을 수 없습니다: $DB_DIR/schema.sql${NC}"
        exit 1
    fi
    
    # 환경 변수에서 DB 정보 가져오기 또는 기본값 사용
    DB_HOST=${DB_HOST:-localhost}
    DB_PORT=${DB_PORT:-5432}
    DB_NAME=${DB_NAME:-iot_monitoring}
    DB_USER=${DB_USER:-postgres}
    
    echo -e "${CYAN}  데이터베이스: $DB_NAME @ $DB_HOST:$DB_PORT${NC}"
    
    # 데이터베이스 생성 시도 (이미 존재하면 무시)
    psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -c "CREATE DATABASE $DB_NAME;" 2>/dev/null || true
    
    # 스키마 적용
    psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -f "$DB_DIR/schema.sql"
    
    echo -e "${GREEN}✅ 데이터베이스 초기화 완료${NC}"
}

# 함수: 백엔드 서버 시작
start_backend() {
    echo -e "${BLUE}🚀 백엔드 서버 시작 중...${NC}"
    
    if [ ! -d "$BACKEND_DIR" ]; then
        echo -e "${RED}❌ 백엔드 디렉토리를 찾을 수 없습니다: $BACKEND_DIR${NC}"
        exit 1
    fi
    
    cd "$BACKEND_DIR"
    
    # 이미 실행 중인지 확인
    if pgrep -f "node.*server.js" > /dev/null; then
        echo -e "${YELLOW}⚠️ 백엔드 서버가 이미 실행 중입니다${NC}"
        return
    fi
    
    # .env 파일 생성 (없으면)
    if [ ! -f ".env" ]; then
        echo -e "${CYAN}  → .env 파일 생성 중...${NC}"
        cat > .env << EOF
DB_HOST=localhost
DB_PORT=5432
DB_NAME=iot_monitoring
DB_USER=postgres
DB_PASSWORD=password
PORT=3001
CORS_ORIGIN=*
EOF
    fi
    
    npm start &
    BACKEND_PID=$!
    echo $BACKEND_PID > "$PROJECT_DIR/.backend.pid"
    
    echo -e "${GREEN}✅ 백엔드 서버 시작됨 (PID: $BACKEND_PID)${NC}"
    echo -e "${CYAN}   API: http://localhost:3001/api${NC}"
    echo -e "${CYAN}   WebSocket: ws://localhost:3001${NC}"
}

# 함수: 프론트엔드 시작
start_frontend() {
    echo -e "${BLUE}🎨 프론트엔드 시작 중...${NC}"
    
    if [ ! -d "$FRONTEND_DIR" ]; then
        echo -e "${RED}❌ 프론트엔드 디렉토리를 찾을 수 없습니다: $FRONTEND_DIR${NC}"
        exit 1
    fi
    
    cd "$FRONTEND_DIR"
    
    # 이미 실행 중인지 확인
    if pgrep -f "react-scripts start" > /dev/null; then
        echo -e "${YELLOW}⚠️ 프론트엔드가 이미 실행 중입니다${NC}"
        return
    fi
    
    # .env 파일 생성 (없으면)
    if [ ! -f ".env" ]; then
        echo -e "${CYAN}  → .env 파일 생성 중...${NC}"
        cat > .env << EOF
REACT_APP_API_URL=http://localhost:3001/api
REACT_APP_WS_URL=ws://localhost:3001
EOF
    fi
    
    npm start &
    FRONTEND_PID=$!
    echo $FRONTEND_PID > "$PROJECT_DIR/.frontend.pid"
    
    echo -e "${GREEN}✅ 프론트엔드 시작됨 (PID: $FRONTEND_PID)${NC}"
    echo -e "${CYAN}   URL: http://localhost:3000${NC}"
}

# 함수: 센서 수집 시작
start_sensor() {
    echo -e "${BLUE}📡 센서 데이터 수집 시작 중...${NC}"
    
    if [ ! -d "$RPI_DIR" ]; then
        echo -e "${RED}❌ Raspberry Pi 디렉토리를 찾을 수 없습니다: $RPI_DIR${NC}"
        exit 1
    fi
    
    cd "$RPI_DIR"
    
    # 이미 실행 중인지 확인
    if pgrep -f "sensor_collector.py" > /dev/null; then
        echo -e "${YELLOW}⚠️ 센서 수집기가 이미 실행 중입니다${NC}"
        return
    fi
    
    # 가상환경 활성화 후 실행
    if [ -d "venv" ]; then
        source venv/bin/activate
        python3 sensor_collector.py &
        SENSOR_PID=$!
        deactivate
    else
        python3 sensor_collector.py &
        SENSOR_PID=$!
    fi
    
    echo $SENSOR_PID > "$PROJECT_DIR/.sensor.pid"
    
    echo -e "${GREEN}✅ 센서 수집 시작됨 (PID: $SENSOR_PID)${NC}"
}

# 함수: PDLC 제스처 제어 시작
start_pdlc() {
    echo -e "${BLUE}🖐️ PDLC 제스처 제어 시작 중...${NC}"
    
    if [ ! -d "$RPI_DIR" ]; then
        echo -e "${RED}❌ Raspberry Pi 디렉토리를 찾을 수 없습니다: $RPI_DIR${NC}"
        exit 1
    fi
    
    cd "$RPI_DIR"
    
    # 이미 실행 중인지 확인
    if pgrep -f "pdlc_gesture_opencv.py" > /dev/null; then
        echo -e "${YELLOW}⚠️ PDLC 제스처 제어가 이미 실행 중입니다${NC}"
        return
    fi
    
    # 가상환경 활성화 후 실행
    if [ -d "venv" ]; then
        source venv/bin/activate
        python3 pdlc_gesture_opencv.py &
        PDLC_PID=$!
        deactivate
    else
        python3 pdlc_gesture_opencv.py &
        PDLC_PID=$!
    fi
    
    echo $PDLC_PID > "$PROJECT_DIR/.pdlc.pid"
    
    echo -e "${GREEN}✅ PDLC 제스처 제어 시작됨 (PID: $PDLC_PID)${NC}"
    echo -e "${CYAN}   핀 설정: GPIO 17 (물리적 핀 11)${NC}"
}

# 함수: 모든 프로세스 종료
stop_all() {
    echo -e "${BLUE}🛑 모든 프로세스 종료 중...${NC}"
    
    # PID 파일에서 프로세스 종료
    for pid_file in ".backend.pid" ".frontend.pid" ".sensor.pid" ".pdlc.pid"; do
        if [ -f "$PROJECT_DIR/$pid_file" ]; then
            PID=$(cat "$PROJECT_DIR/$pid_file")
            if kill -0 "$PID" 2>/dev/null; then
                kill "$PID" 2>/dev/null || true
                echo -e "${CYAN}  → 프로세스 종료됨 (PID: $PID)${NC}"
            fi
            rm -f "$PROJECT_DIR/$pid_file"
        fi
    done
    
    # 프로세스 이름으로 종료 (백업)
    pkill -f "node.*server.js" 2>/dev/null || true
    pkill -f "react-scripts start" 2>/dev/null || true
    pkill -f "sensor_collector.py" 2>/dev/null || true
    pkill -f "pdlc_gesture_opencv.py" 2>/dev/null || true
    
    echo -e "${GREEN}✅ 모든 프로세스 종료됨${NC}"
}

# 함수: 시스템 상태 확인
check_status() {
    echo -e "${BLUE}📊 시스템 상태${NC}"
    echo ""
    
    # PostgreSQL
    if pg_isready -h localhost -p 5432 > /dev/null 2>&1; then
        echo -e "  🗄️ PostgreSQL: ${GREEN}실행 중${NC}"
    else
        echo -e "  🗄️ PostgreSQL: ${RED}중지됨${NC}"
    fi
    
    # Backend
    if pgrep -f "node.*server.js" > /dev/null; then
        echo -e "  🚀 Backend: ${GREEN}실행 중${NC} (http://localhost:3001)"
    else
        echo -e "  🚀 Backend: ${RED}중지됨${NC}"
    fi
    
    # Frontend
    if pgrep -f "react-scripts" > /dev/null; then
        echo -e "  🎨 Frontend: ${GREEN}실행 중${NC} (http://localhost:3000)"
    else
        echo -e "  🎨 Frontend: ${RED}중지됨${NC}"
    fi
    
    # Sensor Collector
    if pgrep -f "sensor_collector.py" > /dev/null; then
        echo -e "  📡 Sensor Collector: ${GREEN}실행 중${NC}"
    else
        echo -e "  📡 Sensor Collector: ${RED}중지됨${NC}"
    fi
    
    # PDLC Gesture
    if pgrep -f "pdlc_gesture_opencv.py" > /dev/null; then
        echo -e "  🖐️ PDLC Gesture: ${GREEN}실행 중${NC}"
    else
        echo -e "  🖐️ PDLC Gesture: ${RED}중지됨${NC}"
    fi
    
    echo ""
}

# 메인 로직
case "${1:-help}" in
    all)
        start_backend
        sleep 2
        start_frontend
        echo ""
        echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}  ✅ 시스템이 시작되었습니다!${NC}"
        echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
        echo ""
        echo -e "${CYAN}  📊 Dashboard: http://localhost:3000${NC}"
        echo -e "${CYAN}  🚀 API: http://localhost:3001/api${NC}"
        echo -e "${CYAN}  📡 WebSocket: ws://localhost:3001${NC}"
        echo ""
        ;;
    backend)
        start_backend
        ;;
    frontend)
        start_frontend
        ;;
    sensor)
        start_sensor
        ;;
    pdlc)
        start_pdlc
        ;;
    db-init)
        init_database
        ;;
    install)
        install_dependencies
        ;;
    stop)
        stop_all
        ;;
    status)
        check_status
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        echo -e "${RED}❌ 알 수 없는 명령: $1${NC}"
        echo ""
        show_help
        exit 1
        ;;
esac









