# 🎧 ANC (Active Noise Cancelling) 시스템

## 📁 구조

```
anc-system/
├── anc_processor.py      # 노트북에서 실행 (ANC 계산 + Pi5 전송)
├── pico_anc_firmware.py  # Pico에 업로드 (마이크 → 진동자)
├── requirements.txt
└── README.md
```

## 🔄 시스템 흐름

```
┌──────────────────────────────────────────────────────────┐
│  실시간 ANC 루프 (지연 최소화!)                            │
│                                                          │
│  [마이크] → [Pico ADC] ─USB→ [노트북 ANC] ─USB→ [Pico PWM] → [진동자]
│                              │                           │
│                              │ 예상 지연: ~6ms            │
└──────────────────────────────┼───────────────────────────┘
                               │
                               │ (1초 간격, 딜레이 OK)
                               ▼
                    [Pi 5 서버] → [DB] → [UI]
                        dB 수치만 전송
```

## 🔧 하드웨어 연결

### Pico 핀 배치
```
마이크 모듈:
  VCC  → Pico 3.3V (핀 36)
  GND  → Pico GND  (핀 38)
  OUT  → Pico GP26 (핀 31, ADC0)

진동자/스피커:
  IN   → Pico GP0  (핀 1, PWM)
  VCC  → 외부 전원 또는 Pico VBUS
  GND  → Pico GND
```

## 🚀 실행 방법

### 1단계: Pico 펌웨어 업로드

1. Thonny 실행
2. `pico_anc_firmware.py` 열기
3. Pico에 **main.py**로 저장

### 2단계: 노트북에서 ANC 프로세서 실행

```bash
# 의존성 설치
pip install -r requirements.txt

# 설정 수정 (anc_processor.py)
PI5_SERVER = "http://192.168.35.33:3001"  # Pi 5 IP 주소

# 실행
python anc_processor.py
```

### 3단계: Pi 5에서 서버 실행

```bash
cd ~/smart-home-iot/iot-monitoring
./start.sh backend
./start.sh frontend  # 웹 UI
```

### 4단계: UI 확인

브라우저에서 `http://Pi5-IP:3000` 접속
→ **소음 분석** 카드에서 dB 수치 확인

## ⚙️ 설정 조정

### 지연 시간 줄이기

`anc_processor.py`에서:
```python
BUFFER_SIZE = 128   # 256 → 128 (지연 감소, CPU 부하 증가)
```

### Pi 5 전송 간격

```python
SEND_INTERVAL = 0.5  # 1초 → 0.5초 (더 빠른 UI 업데이트)
```

### ANC 알고리즘 튜닝

```python
FILTER_LENGTH = 64   # 필터 길이 (작을수록 빠름, 품질 저하)
step_size = 0.02     # 학습률 (클수록 빠른 적응, 불안정 가능)
```

## 📊 예상 성능

| 항목 | 값 |
|------|-----|
| 샘플레이트 | 44,100 Hz |
| 버퍼 크기 | 256 samples |
| **예상 지연** | **~6 ms** |
| Pi 5 전송 | 1초 간격 |

## 🔍 문제 해결

### "Pico를 찾을 수 없습니다"
```bash
# Windows
장치 관리자에서 COM 포트 확인

# Linux/Mac
ls /dev/tty*
```

### 소리가 이상함 / 피드백 발생
- 마이크와 진동자 사이 거리 조절
- `step_size` 값 줄이기 (0.01 → 0.005)
- `FILTER_LENGTH` 늘리기

### Pi 5에 데이터가 안 들어감
- Pi 5 IP 주소 확인
- 백엔드 서버 실행 확인: `./start.sh status`
