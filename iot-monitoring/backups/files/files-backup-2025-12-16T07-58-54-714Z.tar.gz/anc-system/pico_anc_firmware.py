# =====================================================
# 🎤 Pico ANC 펌웨어 (MicroPython)
# =====================================================
# Pico에 main.py로 업로드!
#
# 역할:
#   1. ADC로 마이크 신호 읽기
#   2. USB Serial로 노트북에 전송
#   3. 노트북에서 받은 상쇄음을 DAC/PWM으로 진동자 출력
#
# 하드웨어 연결:
#   마이크 OUT  → GP26 (ADC0, 핀 31)
#   마이크 VCC  → 3.3V (핀 36)
#   마이크 GND  → GND (핀 38)
#   진동자 IN   → GP0 (PWM, 핀 1)
#   진동자 VCC  → 3.3V 또는 외부 전원
#   진동자 GND  → GND

import machine
import sys
import time
import struct
from machine import ADC, PWM, Pin

# =====================================================
# 📌 설정
# =====================================================
SAMPLE_RATE = 44100         # 샘플레이트 (Hz)
BUFFER_SIZE = 256           # 버퍼 크기
ADC_BITS = 12               # ADC 해상도 (Pico는 12-bit)

# =====================================================
# 하드웨어 초기화
# =====================================================
# 마이크 입력 (ADC)
mic_adc = ADC(26)  # GP26 = ADC0

# 진동자 출력 (PWM)
# PWM 주파수를 높게 설정해서 오디오 신호 출력
vibrator_pwm = PWM(Pin(0))
vibrator_pwm.freq(250000)  # 250kHz PWM (오디오보다 훨씬 높게)
vibrator_pwm.duty_u16(32768)  # 중앙값 (무음)

# LED (상태 표시)
led = Pin("LED", Pin.OUT)

# =====================================================
# 유틸리티 함수
# =====================================================
def read_mic_sample():
    """마이크에서 12-bit 샘플 읽기 → 16-bit로 변환"""
    raw = mic_adc.read_u16()  # 실제로는 12-bit가 16-bit로 확장됨
    # DC 오프셋 제거 (중앙값 기준)
    sample = raw - 32768
    return sample

def output_to_vibrator(sample):
    """상쇄음을 진동자로 출력"""
    # -32768 ~ 32767 → 0 ~ 65535로 변환
    pwm_value = sample + 32768
    pwm_value = max(0, min(65535, pwm_value))
    vibrator_pwm.duty_u16(int(pwm_value))

# =====================================================
# 메인 루프
# =====================================================
def main():
    print("🎤 Pico ANC Firmware Started")
    
    # 샘플 간격 (마이크로초)
    sample_interval_us = 1_000_000 // SAMPLE_RATE
    
    # 버퍼
    send_buffer = bytearray(BUFFER_SIZE * 2)  # 16-bit samples
    recv_buffer = bytearray(BUFFER_SIZE * 2)
    
    buffer_idx = 0
    led_toggle_count = 0
    
    while True:
        start_time = time.ticks_us()
        
        # 1. 마이크 샘플 읽기
        sample = read_mic_sample()
        
        # 2. 버퍼에 저장 (16-bit little-endian)
        struct.pack_into('<h', send_buffer, buffer_idx * 2, sample)
        buffer_idx += 1
        
        # 3. 버퍼가 차면 전송
        if buffer_idx >= BUFFER_SIZE:
            # USB Serial로 전송
            sys.stdout.buffer.write(send_buffer)
            
            # 노트북에서 상쇄음 수신
            bytes_read = sys.stdin.buffer.readinto(recv_buffer)
            
            if bytes_read and bytes_read >= 2:
                # 수신된 상쇄음을 진동자로 출력
                for i in range(min(bytes_read // 2, BUFFER_SIZE)):
                    anti_sample = struct.unpack_from('<h', recv_buffer, i * 2)[0]
                    output_to_vibrator(anti_sample)
            
            buffer_idx = 0
            
            # LED 깜빡임 (동작 확인용)
            led_toggle_count += 1
            if led_toggle_count >= 10:
                led.toggle()
                led_toggle_count = 0
        
        # 4. 정확한 샘플레이트 유지
        elapsed = time.ticks_diff(time.ticks_us(), start_time)
        if elapsed < sample_interval_us:
            time.sleep_us(sample_interval_us - elapsed)

# 실행
if __name__ == "__main__":
    main()
